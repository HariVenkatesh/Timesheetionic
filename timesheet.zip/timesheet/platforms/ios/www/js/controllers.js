var webServiceURL = "http://172.16.11.79:800/IOTimeSheetsServices.svc/restful";
var parameter;
var alertPopup;
var confirmPopup;
var timeSheetSavedFrom;
var now;
var day;
var month;
var year;
var first;
var firstFullDate;
var lastFullDate;
var timeSheetEmpName;
var HoursPerWeek;
var HoursWorked = 0;
var weeklyStartDate;

var app = angular.module('app.controllers', ['ionic']);



/* Root Scope

app.run(function($rootScope,$ionicPopup){

        var alertPopup;
        $rootScope.showAlert = function(Title,Msg) {
        alertPopup = $ionicPopup.alert({
                                           title: Title,
                                           template: '<center>'+Msg+'</center>'
                                           });
        
        alertPopup.then(function(res) {
                        $location.path(path);
                        alert("then");
                        });

        };
        
        });
*/


app.factory('commonFunctions', function($ionicPopup,$ionicLoading,$state,$http) {
            return {
            showAlert: function(Title,Msg,Path) {
            alertPopup = $ionicPopup.alert({
                                               title: Title,
                                               template: '<center>'+Msg+'</center>'
                           });
            alertPopup.then(function(res) {
                $state.go(Path);
                                        });
                    },
            confirmAlert: function(Title,Msg,Path){
            confirmPopup = $ionicPopup.confirm({
                                                   title: Title,
                                                   template: '<center>'+Msg+'</center>'
                                                   });
            
            confirmPopup.then(function(res) {
                              if(res) {
                              $state.go(Path);
                              } else {
                              console.log('stay in same page');
                              }
                              });
            },
            showLoading: function(){
                $ionicLoading.show({template: 'Loading..<br><ion-spinner icon="spiral"></ion-spinner>'});
                    },
            hideLoading: function(){
                $ionicLoading.hide();
                    },
            webService: function(method,parameter,callback){
            this.showLoading();
            $http.post("http://123.255.250.197:2239/IOTimeSheetsServices.svc/restful/"+method,parameter).then(function(response){
                            //console.log(response);
                            callback(response);
                                                                                                              
                },function(err){
                            $ionicPopup.alert({
                                              title: "Timesheet",
                                              template: '<center>'+JSON.stringify(err)+'</center>'
                                              });
                            $ionicLoading.hide();
                });
            },
             /*-- Method To Check Internet Connection --*/
            checkConnection: function(){
            var networkState = navigator.connection.type;
            var states = {};
            states[Connection.UNKNOWN] = 'Unknown connection';
            states[Connection.ETHERNET] = 'Ethernet connection';
            states[Connection.WIFI] = 'WiFi connection';
            states[Connection.CELL_2G] = 'Cell 2G connection';
            states[Connection.CELL_3G] = 'Cell 3G connection';
            states[Connection.CELL_4G] = 'Cell 4G connection';
            states[Connection.NONE] = 'No network connection';
            if (states[networkState] == 'No network connection') {
            return false;
            } else {
            return true;
            }
            }, /*-- End of Internet Connection Method --*/
            /*-- Exception Handling Method --*/
            errorHandling: function(){
            try {
            originalCode();
            } catch (err) {
            alert(err.message);
            }
            }/*-- End Of Exception Handling Block --*/
                };
            });


app.controller('timesheetLoginPgCtrl', function($scope,$state,commonFunctions) {
              
               $scope.UserName = "E005";
               $scope.Password = "1234";

            $scope.timeSheetLogin = function(un,pwd){

            parameter = {"employee":{"EmployeeNo": un,"Password": pwd}};
            
            if((un=="" || un==undefined) && (pwd=="" || pwd==undefined)){
               commonFunctions.showAlert("Timesheet","Please enter username & password");
            }else if(un=="" || un==undefined){
            commonFunctions.showAlert("Timesheet","Please enter username");
            }else if(pwd=="" || pwd==undefined){
            commonFunctions.showAlert("Timesheet","Please enter password");
            }else{
               
            commonFunctions.webService("GetEmployee",parameter,function(res){
             console.log(JSON.stringify(res));
              if (res.data.GetEmployeeResult.Status) {
                 commonFunctions.hideLoading();
                 $state.go('timesheetHomePg');
                localStorage.setItem("timeSheetEmployeeNumber",un);
                localStorage.setItem("timeSheetPayRollNumber",res.data.GetEmployeeResult.PayrollNumber);
                timeSheetEmpName = res.data.GetEmployeeResult.FullName;
                HoursPerWeek = res.data.GetEmployeeResult.HoursPerWeek;
              }else {
                commonFunctions.hideLoading();
                commonFunctions.showAlert("Timesheet","Invalid Username or Password");
              }
               });
               
            }
            }
            
})
   
app.controller('timesheetChangePWDPgCtrl', function($scope) {

})

app.controller('timesheetHomePgCtrl', function($state,$scope,commonFunctions) {
               
               $scope.timesheetEmpName = timeSheetEmpName;
               $scope.timesheetEmpHoursPerWeek = "Min Hrs:  "+HoursPerWeek;
               $scope.timesheetHoursWorked = "Hrs Worked:"+HoursWorked;
               
               $scope.timesheetLogout = function(){
               commonFunctions.confirmAlert("Timesheet","Are you sure you want to logout?","timesheetLoginPg");
               
               }
               
               $scope.generateTimeSheetListView = function(type){
               
               if(type=="filter"){
               
               
               
               }else if(type=="list"){
               
               
               
               }else if(type=="daily"){
               
               timeSheetSavedFrom = "daily";
               now = new Date();
               day = now.getDate();
               month = now.getMonth()+1;
               year = now.getFullYear();
               
               if(day<10){
               day = "0"+day;
               }
               
               if(month<10){
               month = "0"+month;
               }
               
               firstFullDate = day+"-"+month+"-"+year;
               lastFullDate = day+"-"+month+"-"+year;
               
               parameter = {
               "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
               "startDate":"" +firstFullDate+ "",
               "endDate":"" +lastFullDate+ ""
               }
               $scope.generatingTimesheetListView("daily");
               
               }else if(type=="weekly"){
               
               /*code to find 1st and last day of the current week*/
               timeSheetSavedFrom = "weekly";
               now = new Date();
               first = now.getDate() - now.getDay();
               first = new Date(now.setDate(first)).toUTCString();
               
               //last = new Date(now.setDate(last)).toUTCString();
               
               /* Code to find 1st day of week */
               
               firstFullDate = new Date(first);
               lastFullDate = new Date(first);
               
               day = firstFullDate.getDate();
               weeklyStartDate = firstFullDate.getDate();
               if(day<10){
               day = "0"+day;
               }
               
               month = firstFullDate.getMonth()+1;
               if(month<10){
               
               month = "0"+month;
               }
               
               year = firstFullDate.getFullYear();
               firstFullDate = day+"-"+month+"-"+year;
               
               /* Code to find last day of week*/
               
               lastFullDate.setDate(lastFullDate.getDate() + 6);
               day = lastFullDate.getDate();
               month = lastFullDate.getMonth() + 1;
               year = lastFullDate.getFullYear();
               
               if(day<10){
               day = "0"+day;
               }
               
               if(month<10){
               month = "0"+month;
               }
               
               lastFullDate = day+"-"+month+"-"+year;

               parameter = {
               "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
               "startDate":"" +firstFullDate+ "",
               "endDate":"" +lastFullDate+ ""
               }
               $scope.generatingTimesheetListView("weekly");
               
               }else if(type=="fourtnightly"){
               
               /* Code to find last day of 14 days */
               
               timeSheetSavedFrom = "fourtnightly";
               lastFullDate = new Date();
               
               day = lastFullDate.getDate();
               if(day<10){
               day = "0"+day;
               }
               
               month = lastFullDate.getMonth()+1;
               if(month<10){
               month = "0"+month;
               }
               
               year = lastFullDate.getFullYear();
               lastFullDate = day+"-"+month+"-"+year;
               
               /* Code to find first day of 14 days*/
               
               fortNightDays = new Date(+new Date - 12096e5);
               
               day = fortNightDays.getDate();
               if(day<10){
               day = "0"+day;
               }
               
               month = fortNightDays.getMonth()+1;
               if(month<10){
               month = "0"+month;
               }
               year = fortNightDays.getFullYear();
               
               firstFullDate = day+"-"+month+"-"+year;
               
               parameter = {
               "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
               "startDate":"" +firstFullDate+ "",
               "endDate":"" +lastFullDate+ ""
               }
               
               generatingTimesheetListView("fourtnightly");
               
               }else if(type=="monthly"){
               
               timeSheetSavedFrom = "monthly";
               
               /* Code to find before 30 days*/
               
               now = new Date();
               firstFullDate = new Date(now.getFullYear(),now.getMonth(),1);
               lastFullDate =  new Date(now.getFullYear(),now.getMonth()+1,0);
               
               firstFullDate = firstFullDate.getDate()+"-"+(firstFullDate.getMonth()+1)+"-"+firstFullDate.getFullYear();
               lastFullDate = lastFullDate.getDate()+"-"+(lastFullDate.getMonth()+1)+"-"+lastFullDate.getFullYear();
               
               parameter = {
               "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
               "startDate":"" +firstFullDate+ "",
               "endDate":"" +lastFullDate+ ""
               }
               
               $scope.generatingTimesheetListView("monthly");
               
               
               }
               }
               
               $scope.generatingTimesheetListView = function(type){
               
               commonFunctions.webService("GetTimesheetEntries",parameter,function(res){
                                          console.log("parameter",JSON.stringify(parameter));
                                          console.log("GetTimesheetEntries"+JSON.stringify(res));
                                          if (res.data.GetTimesheetEntriesResult.length==0 || response.GetTimesheetEntriesResult.length==null) {
                                          
                                          commonFunctions.hideLoading();
                                          if(fromPg=="timeSheetLoginPg"){
                                          fromPg = "";
                                          console.log("dont show alert");
                                          }else{
                                          if(type=="filter"){
//                                          $("#timeSheetListview").empty();
                                          commonFunctions.showAlert("No Timesheet found to show!", "Timesheet");
                                          }else{
//                                          $("#timeSheetListview").empty();
                                          commonFunctions.showAlert("No Timesheet found to show!", "Timesheet", function(){
                                            $state.go('timesheetListPg');
                                                    });
                                          }
                                          }
                                          //getEmpDetails();

                                          
                                          }else{
                                          
                                          
                                          
                                          
                                          
                                          
                                          }
                                          
                                          });
               
               }
               
               
               })
   
app.controller('timesheetListPgCtrl', function($scope) {

})



 