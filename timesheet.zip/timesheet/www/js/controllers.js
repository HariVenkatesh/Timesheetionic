angular.module('app.controllers', ['ionic'])


.controller('timesheetLoginPgCtrl', function($scope,$ionicPopup,$ionicLoading) {
            
            var webServiceURL = "http://172.16.11.79:800/IOTimeSheetsServices.svc/restful/";
            var parameter;
            $scope.showAlert = function(Title,Msg,path) {
            
            var alertPopup = $ionicPopup.alert({
                                               title: Title,
                                               template: '<center>'+Msg+'</center>'
                                               });
            
            alertPopup.then(function(res) {
                            $location.path(path);
                            });
            }
            
            $scope.Loading = function (){
            $ionicLoading.show({template: 'Loading..<br><ion-spinner icon="spiral"></ion-spinner>'});
            }
            
            $scope.hideLoading = function (){
            $ionicLoading.hide();
            }
            
            /*-- Method To Check Internet Connection --*/
            
            $scope.checkConnection = function (){
            
            var networkState = navigator.connection.type;
            var states = {};
            states[Connection.UNKNOWN] = 'Unknown connection';
            states[Connection.ETHERNET] = 'Ethernet connection';
            states[Connection.WIFI] = 'WiFi connection';
            states[Connection.CELL_2G] = 'Cell 2G connection';
            states[Connection.CELL_3G] = 'Cell 3G connection';
            states[Connection.CELL_4G] = 'Cell 4G connection';
            states[Connection.NONE] = 'No network connection';
            if (states[networkState] == 'No network connection') {
            return false;
            } else {
            return true;
            }
            }
            
            /*-- End of Internet Connection Method --*/
            
            /*-- Exception Handling Method --*/
            
            $scope.errorHandling = function(originalCode) {
            try {
            originalCode();
            } catch (err) {
            alert(err.message);
            }
            }
            
            /*-- End Of Exception Handling Block --*/

            $scope.timeSheetLogin = function(un,pwd){

            parameter = {"employee":{"EmployeeNo": un,"Password": pwd}};
            
            if((un=="" || un==undefined) && (pwd=="" || pwd==undefined)){
            $scope.showAlert("Timesheet","Please enter username & password");
            }else if(un=="" || un==undefined){
            $scope.showAlert("Timesheet","Please enter username");
            }else if(pwd=="" || pwd==undefined){
            $scope.showAlert("Timesheet","Please enter password");
            }else{
            
            $scope.Apploadingicon();
            if ($scope.checkConnection()) {
            $http.post(webServiceURL+""+methodName,parameter).then(function (res){
                                                               console.log("Companylist"+JSON.stringify(res));
                                                               });
            } else {
            $scope.showAlert("Please check internet connection.", "Timesheet");
            $scope.hideLoadingIcon();
            }


            }
            }
            
            
})
   
.controller('timesheetChangePWDPgCtrl', function($scope) {

})
   
.controller('timesheetListPgCtrl', function($scope) {

})
 