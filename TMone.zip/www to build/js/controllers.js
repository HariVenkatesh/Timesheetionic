/* Staging Server */
var webServiceURL = "http://202.129.196.131:800/IOTimeSheetsServices.svc/restful/";
//var webServiceURL = "http://172.16.11.242:800/IOTimeSheetsServices.svc/restful/";
var parameter;
var alertPopup;
var confirmPopup;
var timeSheetSavedFrom;
var now;
var day;
var month;
var year;
var first;
var firstFullDate;
var lastFullDate;
var timeSheetEmpName;
var HoursPerWeek;
var HoursWorked = 0;
var weeklyStartDate;
var items = [];
var timeSheetStatus;
var noOfPlantEntry;
var taskMatchingForJob = [];

var app = angular.module('app.controllers', ['ionic']);


/* Root Scope

app.run(function($rootScope,$ionicPopup){

        var alertPopup;
        $rootScope.showAlert = function(Title,Msg) {
        alertPopup = $ionicPopup.alert({
                                           title: Title,
                                           template: '<center>'+Msg+'</center>'
                                           });
        
        alertPopup.then(function(res) {
                        $location.path(path);
                        alert("then");
                        });

        };
        
        });
*/


app.factory('commonFunctions', function($ionicPopup,$ionicLoading,$state,$http) {
            return {
            showAlert: function(Title,Msg,Path) {
            alertPopup = $ionicPopup.alert({
                                               title: Title,
                                               template: '<center>'+Msg+'</center>'
                           });
            alertPopup.then(function(res) {
                $state.go(Path);
                                        });
                    },
            confirmAlert: function(Title,Msg,Path){
            confirmPopup = $ionicPopup.confirm({
                                                   title: Title,
                                                   template: '<center>'+Msg+'</center>'
                                                   });
            
            confirmPopup.then(function(res) {
                              if(res) {
                              $state.go(Path);
                              } else {
                              console.log('stay in same page');
                              }
                              });
            },
            showLoading: function(){
                $ionicLoading.show({template: 'Loading..<br><ion-spinner icon="spiral"></ion-spinner>'});
                    },
            hideLoading: function(){
                $ionicLoading.hide();
                    },
            webService: function(method,parameter,callback){
            this.showLoading();
            $http.post(webServiceURL+method,parameter).then(function(response){
                            //console.log(response);
                            callback(response);
                                                                                                              
                },function(err){
                            $ionicPopup.alert({
                                              title: "Timesheet",
                                              template: '<center>'+JSON.stringify(err)+'</center>'
                                              });
                            $ionicLoading.hide();
                });
            },
             /*-- Method To Check Internet Connection --*/
            checkConnection: function(){
            var networkState = navigator.connection.type;
            var states = {};
            states[Connection.UNKNOWN] = 'Unknown connection';
            states[Connection.ETHERNET] = 'Ethernet connection';
            states[Connection.WIFI] = 'WiFi connection';
            states[Connection.CELL_2G] = 'Cell 2G connection';
            states[Connection.CELL_3G] = 'Cell 3G connection';
            states[Connection.CELL_4G] = 'Cell 4G connection';
            states[Connection.NONE] = 'No network connection';
            if (states[networkState] == 'No network connection') {
            return false;
            } else {
            return true;
            }
            }, /*-- End of Internet Connection Method --*/
            /*-- Exception Handling Method --*/
            errorHandling: function(){
            try {
            originalCode();
            } catch (err) {
            alert(err.message);
            }
            }/*-- End Of Exception Handling Block --*/
                };
            });


app.controller('timesheetLoginPgCtrl', function($scope,$state,commonFunctions,listData) {
              
               $scope.UserName = "E005";
               $scope.Password = "1234";
               
               now = new Date();
               first = now.getDate() - now.getDay();
               first = new Date(now.setDate(first)).toUTCString();
               firstFullDate = new Date(first);
               lastFullDate = new Date(first);
               
               day = firstFullDate.getDate();
               weeklyStartDate = firstFullDate.getDate();
               if(day<10){
               day = "0"+day;
               }
               
               month = firstFullDate.getMonth()+1;
               if(month<10){
               
               month = "0"+month;
               }
               
               year = firstFullDate.getFullYear();
               firstFullDate = day+"-"+month+"-"+year;
               
               /* Code to find last day of week*/
               
               lastFullDate.setDate(lastFullDate.getDate() + 6);
               day = lastFullDate.getDate();
               month = lastFullDate.getMonth() + 1;
               year = lastFullDate.getFullYear();
               
               if(day<10){
               day = "0"+day;
               }
               
               if(month<10){
               month = "0"+month;
               }
               
               lastFullDate = day+"-"+month+"-"+year;
               
               
            $scope.timeSheetLogin = function(un,pwd){

            parameter = {"employee":{"EmployeeNo": un,"Password": pwd,"frmDate": firstFullDate,"toDate": lastFullDate }};
            
            if((un=="" || un==undefined) && (pwd=="" || pwd==undefined)){
               commonFunctions.showAlert("Timesheet","Please enter username & password");
            }else if(un=="" || un==undefined){
            commonFunctions.showAlert("Timesheet","Please enter username");
            }else if(pwd=="" || pwd==undefined){
            commonFunctions.showAlert("Timesheet","Please enter password");
            }else{
               
            commonFunctions.webService("GetEmployee",parameter,function(res){
             console.log(JSON.stringify(res));
              if (res.data.GetEmployeeResult.Status) {
                 commonFunctions.hideLoading();
                 $state.go('timesheetHomePg');
                localStorage.setItem("timeSheetEmployeeNumber",un);
                localStorage.setItem("timeSheetPayRollNumber",res.data.GetEmployeeResult.PayrollNumber);
                timeSheetEmpName = res.data.GetEmployeeResult.FullName;
                HoursPerWeek = res.data.GetEmployeeResult.HoursPerWeek;
                HoursWorked = res.data.GetEmployeeResult.TotalUnits;
                //listData.getEmpDetails(timeSheetEmpName,HoursPerWeek,HoursWorked);
              }else {
                commonFunctions.hideLoading();
                commonFunctions.showAlert("Timesheet","Invalid Username or Password");
              }
               });
               
            }
            }
            
})
   
app.controller('timesheetChangePWDPgCtrl', function($scope) {

               });

app.controller('timesheetHomePgCtrl', function($state,$rootScope,$scope,commonFunctions,listData) {
               
               $rootScope.timesheetEmpName = timeSheetEmpName;
               $rootScope.timesheetEmpHoursPerWeek = "Min Hrs:  "+HoursPerWeek;
               $rootScope.timesheetHoursWorked = "Hrs Worked:"+HoursWorked;
               
               $scope.timesheetLogout = function(){
               commonFunctions.confirmAlert("Timesheet","Are you sure you want to logout?","timesheetLoginPg");
               }
               
               $scope.clearAddTmeSheetFields = function(){
               $rootScope.setValue = 1;
               }
               
               $scope.generateTimeSheetListView = function(type){
               
               if(type=="filter"){
               
               parameter = {
               "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
               "startDate":"" +$("#timeSheetPgFrom").val()+ "",
               "endDate":"" +$("#timeSheetPgTo").val()+ ""
               }
               $scope.generatingTimesheetListView("filter");
               
               }else if(type=="list"){
               
               parameter = { "employeeNum": localStorage.getItem("timeSheetEmployeeNumber") };
               $scope.generatingTimesheetListView("list");
               
               }else if(type=="daily"){
               
               timeSheetSavedFrom = "daily";
               now = new Date();
               day = now.getDate();
               month = now.getMonth()+1;
               year = now.getFullYear();
               
               if(day<10){
               day = "0"+day;
               }
               
               if(month<10){
               month = "0"+month;
               }
               
               firstFullDate = day+"-"+month+"-"+year;
               lastFullDate = day+"-"+month+"-"+year;
               
               parameter = {
               "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
               "startDate":"" +firstFullDate+ "",
               "endDate":"" +lastFullDate+ ""
               }
               $scope.generatingTimesheetListView("daily");
               
               }else if(type=="weekly"){
               
               /*code to find 1st and last day of the current week*/
               timeSheetSavedFrom = "weekly";
               now = new Date();
               first = now.getDate() - now.getDay();
               first = new Date(now.setDate(first)).toUTCString();
               
               //last = new Date(now.setDate(last)).toUTCString();
               
               /* Code to find 1st day of week */
               
               firstFullDate = new Date(first);
               lastFullDate = new Date(first);
               
               day = firstFullDate.getDate();
               weeklyStartDate = firstFullDate.getDate();
               if(day<10){
               day = "0"+day;
               }
               
               month = firstFullDate.getMonth()+1;
               if(month<10){
               
               month = "0"+month;
               }
               
               year = firstFullDate.getFullYear();
               firstFullDate = day+"-"+month+"-"+year;
               
               /* Code to find last day of week*/
               
               lastFullDate.setDate(lastFullDate.getDate() + 6);
               day = lastFullDate.getDate();
               month = lastFullDate.getMonth() + 1;
               year = lastFullDate.getFullYear();
               
               if(day<10){
               day = "0"+day;
               }
               
               if(month<10){
               month = "0"+month;
               }
               
               lastFullDate = day+"-"+month+"-"+year;

               parameter = {
               "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
               "startDate":"" +firstFullDate+ "",
               "endDate":"" +lastFullDate+ ""
               }
               $scope.generatingTimesheetListView("weekly");
               
               }else if(type=="fourtnightly"){
               
               /* Code to find last day of 14 days */
               
               timeSheetSavedFrom = "fourtnightly";
               lastFullDate = new Date();
               
               day = lastFullDate.getDate();
               if(day<10){
               day = "0"+day;
               }
               
               month = lastFullDate.getMonth()+1;
               if(month<10){
               month = "0"+month;
               }
               
               year = lastFullDate.getFullYear();
               lastFullDate = day+"-"+month+"-"+year;
               
               /* Code to find first day of 14 days*/
               
               fortNightDays = new Date(+new Date - 12096e5);
               
               day = fortNightDays.getDate();
               if(day<10){
               day = "0"+day;
               }
               
               month = fortNightDays.getMonth()+1;
               if(month<10){
               month = "0"+month;
               }
               year = fortNightDays.getFullYear();
               
               firstFullDate = day+"-"+month+"-"+year;
               
               parameter = {
               "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
               "startDate":"" +firstFullDate+ "",
               "endDate":"" +lastFullDate+ ""
               }
               
               $scope.generatingTimesheetListView("fourtnightly");
               
               }else if(type=="monthly"){
               
               timeSheetSavedFrom = "monthly";
               
               /* Code to find before 30 days*/
               
               now = new Date();
               firstFullDate = new Date(now.getFullYear(),now.getMonth(),1);
               lastFullDate =  new Date(now.getFullYear(),now.getMonth()+1,0);
               
               firstFullDate = firstFullDate.getDate()+"-"+(firstFullDate.getMonth()+1)+"-"+firstFullDate.getFullYear();
               lastFullDate = lastFullDate.getDate()+"-"+(lastFullDate.getMonth()+1)+"-"+lastFullDate.getFullYear();
               
               parameter = {
               "employeeNum": localStorage.getItem("timeSheetEmployeeNumber"),
               "startDate":"" +firstFullDate+ "",
               "endDate":"" +lastFullDate+ ""
               }
               $scope.generatingTimesheetListView("monthly");
               }
               }
               
               $scope.generatingTimesheetListView = function(type){
               commonFunctions.webService("GetTimesheetEntries",parameter,function(res){
                                          console.log("parameter",JSON.stringify(parameter));
                                          console.log("GetTimesheetEntries"+JSON.stringify(res));
                                          if (res.data.GetTimesheetEntriesResult.length == 0) {
                                          commonFunctions.hideLoading();
                                          commonFunctions.showAlert("Timesheet", "No Timesheet found to show!");
                                          }else{
                                          commonFunctions.hideLoading();
                                          $scope.items = [];
                                          for(i=0;i<res.data.GetTimesheetEntriesResult.length;i++){
                                          timeSheetStatus = res.data.GetTimesheetEntriesResult[i].TimesheetStatus;
                                          if(timeSheetStatus == 0){
                                          timeSheetStatus = "";
                                          }else if(timeSheetStatus == 1){
                                          timeSheetStatus = "Submitted";
                                          }else if(timeSheetStatus == 2){
                                          timeSheetStatus = "Approved";
                                          }else if(timeSheetStatus == 3){
                                          timeSheetStatus = "Rejected";
                                          }
                                          
                                          if(res.data.GetTimesheetEntriesResult[i].plantEntryCount==0){
                                          noOfPlantEntry = "No Plant Entry";
                                          }else{
                                          noOfPlantEntry = res.data.GetTimesheetEntriesResult[i].plantEntryCount+ " Plant Entry";
                                          }
                                          
                                          if(res.data.GetTimesheetEntriesResult[i].IsPlant){
                                          $scope.showTruckIcon = "true";
                                          }else{
                                          $scope.showTruckIcon = "false";
                                          }
                                          
                                          $scope.items.push({"job":res.data.GetTimesheetEntriesResult[i].JobFullDescription, "task":res.data.GetTimesheetEntriesResult[i].JobTaskFullDescription,"hours":res.data.GetTimesheetEntriesResult[i].Units,"date":res.data.GetTimesheetEntriesResult[i].WorkDate,"status":timeSheetStatus,"plantentrycount": noOfPlantEntry,"truckIcon": res.data.GetTimesheetEntriesResult[i].IsPlant, "LineNumber": res.data.GetTimesheetEntriesResult[i].LineNumber});
                                          }
                                          listData.listDailyTimeSheet($scope.items);
                                          $state.go('timesheetListPg');
                                          }
                                          });
               }
               
               parameter = "";
               
               commonFunctions.webService("GetPayTransactionTypes",parameter,function(res){
                                          if((res.data.GetPayTransactionTypesResult.length != 0) || (res.data.GetPayTransactionTypesResult.length != null) || (res.data.GetPayTransactionTypesResult.length != undefined)){
                                          commonFunctions.hideLoading();
                                          $rootScope.hoursTypeListArray = [];
                                          for(i=0;i<res.data.GetPayTransactionTypesResult.length;i++){
                                          $rootScope.hoursTypeListArray[i] = {"value":res.data.GetPayTransactionTypesResult[i].Name,"name":res.data.GetPayTransactionTypesResult[i].Value};
                                          }
                                          // $scope.chooseHrsTypeone = hoursTypeListArray;
                                          }else{
                                          commonFunctions.hideLoading();
                                          commonFunctions.showAlert("Timesheet","Cannot able to fetch Hours Type Please Try Again.");
                                          }
                                          });
               
               commonFunctions.webService("GetJobsList", parameter, function(res) {
                                          //console.log("GetJobsList"+JSON.stringify(res));
                                          if((res.data.GetJobsListResult.length != 0) || (res.data.GetJobsListResult.length != null) || (res.data.GetJobsListResult.length != undefined)){
                                          commonFunctions.hideLoading();
                                          $rootScope.jobListArray = [];
                                          for(i=0;i<res.data.GetJobsListResult.length;i++){
                                          $rootScope.jobListArray[i] = {"value":res.data.GetJobsListResult[i].Name,"name":res.data.GetJobsListResult[i].Value};
                                          }
                                          }else{
                                          commonFunctions.hideLoadingIcon();
                                          commonFunctions.showAlert("Timesheet","Cannot able to fetch Job please try again.");
                                          }
                                          });
               
               commonFunctions.webService("GetJobTaskList", parameter, function(res) {
                                          //console.log(JSON.stringify(res));
                                          if((res.data.GetJobTaskListResult.length != 0) || (res.data.GetJobTaskListResult.length != null) || (res.data.GetJobTaskListResult.length != undefined)){
                                          commonFunctions.hideLoading();
                                          $rootScope.taskListArray = [];
                                          for(i=0;i<res.data.GetJobTaskListResult.length;i++){
                                          $rootScope.taskListArray[i] = {"value":res.data.GetJobTaskListResult[i].Name,"name":res.data.GetJobTaskListResult[i].Value,"jobno":res.data.GetJobTaskListResult[i].JobNumber};
                                          }
                                          }else {
                                          commonFunctions.hideLoadingIcon();
                                          commonFunctions.showAlert("Timesheet","Cannot able to fetch Job please try again.");
                                          }
                                          
                                          });
               
               
               });

   
app.controller('timesheetListPgCtrl', function($scope,$rootScope,$state,commonFunctions) {
               
               $scope.clearAddTmeSheetFields = function(){
               $rootScope.setValue = 1;
               }
               
               $scope.itemList = items;
               
               $scope.viewTimesheetDetails = function(lineno){
               localStorage.setItem("timeSheetListLineNumber",lineno);
               
               parameter = {
               "lineNumber":lineno
               }
               
               commonFunctions.webService("GetTimesheetEntry",parameter,function(res){
                                          console.log("GetTimesheetEntries"+JSON.stringify(res));
                                          commonFunctions.hideLoading();
//                                          if(res.data.GetTimesheetEntryResult.TimesheetStatus == 1 || response.GetTimesheetEntryResult.TimesheetStatus == 2 || response.GetTimesheetEntryResult.TimesheetStatus == 3){
//                                          $("#timeSheetSaveIcon").addClass("ui-disabled");
//                                          $("#timeSheetSaveAndNewIcon").addClass("ui-disabled");
//                                          $("#timeSheetSubmittedIcon").addClass("ui-disabled");
//                                          $("#timeSheetPlantEntryDiv").hide();
//                                          }else{
//                                          $("#timeSheetSaveIcon").removeClass("ui-disabled");
//                                          $("#timeSheetSaveAndNewIcon").removeClass("ui-disabled");
//                                          $("#timeSheetSubmittedIcon").removeClass("ui-disabled");
//                                          $("#timeSheetDeleteIcon").removeClass("ui-disabled");
//                                          $("#timeSheetPlantEntryDiv").show();
//                                          }
//                                          if(response.GetTimesheetEntryResult.TimesheetStatus == 1 || response.GetTimesheetEntryResult.TimesheetStatus == 2){
//                                          $("#timeSheetDeleteIcon").addClass("ui-disabled");
//                                          }
//                                          if(response.GetTimesheetEntryResult.TimesheetStatus == 3){
//                                          $(".addTimeSheetPgManagerComments").show();
//                                          }else{
//                                          $(".addTimeSheetPgManagerComments").hide();
//                                          }

                                          str = res.data.GetTimesheetEntryResult.WorkDate;
                                          str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
                                          now = new Date(+str);
                                          day = ("0" + now.getDate()).slice(-2);
                                          month = ("0" + (now.getMonth() + 1)).slice(-2);
                                          
                                          $rootScope.viewTimeSheetInfo = [];
                                          $rootScope.viewTimeSheetInfo = {
                                          "date":now.getFullYear()+"-"+month+"-"+day,
                                          "hourstypecode":res.data.GetTimesheetEntryResult.TransactionTypeCode,
                                          "hoursType":res.data.GetTimesheetEntryResult.TransactionType,
                                          "jobtypecode":res.data.GetTimesheetEntryResult.JobNumber,
                                          "jobType":res.data.GetTimesheetEntryResult.JobFullDescription,
                                          "tasktypecode":res.data.GetTimesheetEntryResult.JobTaskNumber,
                                          "tasktype":res.data.GetTimesheetEntryResult.JobTaskFullDescription,
                                          "units":res.data.GetTimesheetEntryResult.Units,
                                          "employeeComments":res.data.GetTimesheetEntryResult.EmployeeComments,
                                          "managerComments":res.data.GetTimesheetEntryResult.ManagerComments
                                          };
                                           $state.go('timeSheetAddNewPg');
                                          
                                          });
               
               }

               });



app.controller('timeSheetAddNewPg', function($scope,$rootScope,$state,commonFunctions) {
               
//               $scope.timesheetAddDate = "";
//               $scope.jobHrs = "";
//               $scope.comments = "";
//               $scope.chooseHrsType = "";
//               $scope.chooseJobType = "";
//               $scope.chooseTaskType = "";
               
               if($rootScope.setValue){
               console.log("nothing");
               $rootScope.setValue = 0;
               }else{
               $scope.timesheetAddDate = new Date($rootScope.viewTimeSheetInfo.date);
               $scope.jobHrs = $rootScope.viewTimeSheetInfo.units;
               $scope.comments = $rootScope.viewTimeSheetInfo.employeeComments;
               
               for(i=0;i<$rootScope.hoursTypeListArray.length;i++){
               if($rootScope.hoursTypeListArray[i].value == $rootScope.viewTimeSheetInfo.hourstypecode){
               $scope.chooseHrsType = $rootScope.hoursTypeListArray[i].value;
               }
               }
               
               for(i=0;i<$rootScope.jobListArray.length;i++){
               if($rootScope.jobListArray[i].value == $rootScope.viewTimeSheetInfo.jobtypecode){
               $scope.chooseJobType = $rootScope.jobListArray[i].value;
               }
               }
               
               for(i=0;i<$rootScope.taskListArray.length;i++){
               if($rootScope.taskListArray[i].value == $rootScope.viewTimeSheetInfo.tasktypecode){
               $scope.chooseTaskType = $rootScope.taskListArray[i].value;
               }
               }
               }
               
               $scope.addTimeSheet = function(){
               
               
               
               
               }
               
               });




















