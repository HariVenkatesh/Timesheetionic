var app = angular.module('app.services', [])

//.factory('BlankFactory', [function(){
//
//}])
//
//.service('BlankService', [function(){
//
//}]);
var items;
var i, str, now, day, month, year, fullDate;
var EmpDetails = [];
app.service('listData',function(){
            
            var listDailyTimeSheet = function(data){
            items = data;
            for(i=0;i<items.length;i++){
            str = data[i].date;
            str = str.substring(str.lastIndexOf("(")+1,str.lastIndexOf("+"));
            now = new Date(+str);
            day = ("0" + now.getDate()).slice(-2);
            month = ("0" + (now.getMonth() + 1)).slice(-2);
            year = now.getFullYear();
            fullDate = "" +day+"/"+month+"/"+year+ "";
            items[i].date = fullDate;
            }
            };
            
            return {
            listDailyTimeSheet:listDailyTimeSheet
            };
            });