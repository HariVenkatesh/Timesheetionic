angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider

      .state('timesheetLoginPg', {
    url: '/TimesheetLoginPg',
    templateUrl: 'templates/timesheetLoginPg.html',
    controller: 'timesheetLoginPgCtrl'
  })

  .state('timesheetChangePWDPg', {
    url: '/TimesheetChangePassword',
    templateUrl: 'templates/timesheetChangePWDPg.html',
    controller: 'timesheetChangePWDPgCtrl'
  })
        
   .state('timesheetHomePg', {
     url: '/TimesheetHomePage',
     templateUrl: 'templates/timesheetHomePg.html',
     controller: 'timesheetHomePgCtrl'
  })

  .state('timesheetListPg', {
    url: '/TimesheetListPage',
    templateUrl: 'templates/timesheetListPg.html',
    controller: 'timesheetListPgCtrl'
  })
        
  .state('timeSheetAddNewPg', {
         url: '/timeSheetAddNewPg',
         templateUrl: 'templates/timeSheetAddNewPg.html',
         controller: 'timeSheetAddNewPg',
         cache: false
  })
      


$urlRouterProvider.otherwise('/TimesheetLoginPg')

  

});